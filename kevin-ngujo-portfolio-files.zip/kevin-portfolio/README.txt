KEVIN NGUJO MWAGAMBO — PERSONAL PORTFOLIO
========================================

FILES
- index.html   Main single-page portfolio structure
- style.css    Black-and-gold responsive styling
- script.js    Mobile navigation interaction
- assets/      Add your real portrait here

HOW TO PREVIEW
1. Extract the ZIP into your project folder.
2. Open the folder in Visual Studio Code.
3. Add a folder named "assets".
4. Put your portrait inside it and name it: kevin-photo.jpg
5. Open index.html in a browser, or use the VS Code Live Server extension.

IMPORTANT PERSONALISATION BEFORE PUBLISHING
1. Replace the GitHub links (currently https://github.com/) with your actual GitHub profile URL.
2. Replace the featured project's GitHub link with the actual repository URL when it is uploaded.
3. Confirm the technologies listed under Skills reflect what you can confidently demonstrate.
4. Update the education dates if needed.
5. Use a clear, professional portrait with good lighting.

The contact email is set to kevinngujo94@gmail.com.
The page uses Google Fonts, so the font styling requires an internet connection.
